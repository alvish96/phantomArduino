Freelancer Account ID Generator 2.1
 - Release dated May 15, 2010
 - By Cannon and Kazinsal

----------------------------------------

Changelog:

Version 2.1 (May 15, 2010):
 - fixed a small bug where FAM saving wouldn't work if UAC was on

Version 2.0 (April 27, 2010):
 - added a menu bar
 - added the ability to choose a FAM directory
 - added a button to save a new account into FAM's Accounts.dat
 - FLKeyGen will auto-detect for a FAM directory and save its location if one is found
 - FLKeyGen will not let you save a blank text box to FAM's Accounts.dat or an ADF file 

Version 1.2a (March 25, 2010):
 - minor release: changed a few strings

Version 1.2 (March 24, 2010):
 - added help button
 - added silent mode (run with a filename from the command line to create and save a new ID)
 - put the icon in the top left corner of the title bar

----------------------------------------

This code is under a public domain license. Do whatever you want with it. Credit is appreciated.

The usage of the account ID generator is simple. Press the generate button (or a few times, just
to be sure) and then the Save button. You can then save an ADF file with the new account ID to
be imported into the Freelancer Account Manager, or save it directly to FAM if a FAM directory
is found by the auto-detect or if one is specified.

----------------------------------------

The code is compiled using Visual C# 2008, but newer versions should work fine. Works in the
Express Edition too.