﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace FLKeyGen
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length != 0)
            {
                string filename = args[0].ToString();

                // Generate a random-ish seed. This uniquely identifies the user.
                // Freelancer uses the MS windows product ID then the user ID 
                // and the current user name and time.
                string randomKey = System.Guid.NewGuid().ToString() + DateTime.Now.ToLongTimeString();
                string hash = Get_MD5(randomKey);

                // Add the dashes to make the code up to 35 characters.
                string code = "";
                for (int b = 0; b < 32; b += 8)
                {
                    string block = hash.Substring(b, 8);
                    if (b != 0)
                        code += "-";
                    code += block;
                }

                string signature = "";

                // Hash the code and check the length of code and sig

                hash = Get_MD5(code);

                if (code.Length != 35 && hash.Length != 32)
                {
                    signature = "Invalid code";
                    return;
                }

                // Break the hash into 4 blocks and reverse the order 
                // of the digit pairs in each block.

                for (int b = 0; b < 32; b += 8)
                {
                    string blockOut = "";
                    string block = hash.Substring(b, 8);
                    for (int i = 6; i >= 0; i -= 2)
                    {
                        blockOut += block.Substring(i, 2);
                    }
                    if (b != 0)
                        signature += "-";
                    signature += blockOut;
                }

                SaveFileDialog dialog = new SaveFileDialog();
                dialog.Filter = "ADF (*.adf)|*.adf";

                System.IO.StreamWriter fs = System.IO.File.CreateText(filename);
                fs.WriteLine("DB Version: 101");
                fs.WriteLine("New Freelancer Account");
                fs.WriteLine(code);
                fs.WriteLine(signature);
                fs.WriteLine("<COMENTARIO>");
                fs.WriteLine("Created using Cannon and Kazinsal's Freelancer account generator");
                fs.WriteLine("</COMENTARIO>");
                fs.Close();

                Console.WriteLine("Account created to " + filename + ".\n");
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FLKeyGen());
        }

        static string Get_MD5(string input)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(input);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            string password = s.ToString();
            return password;
        }
    }
}
