﻿namespace FLKeyGen
{
    partial class FLKeyGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FLKeyGen));
            this.textBoxCode = new System.Windows.Forms.TextBox();
            this.textBoxSig = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonGenCode = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonHelp = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setFAMDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detectFAMDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveFAM = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxCode
            // 
            this.textBoxCode.Location = new System.Drawing.Point(54, 39);
            this.textBoxCode.Name = "textBoxCode";
            this.textBoxCode.Size = new System.Drawing.Size(226, 20);
            this.textBoxCode.TabIndex = 1;
            this.textBoxCode.TextChanged += new System.EventHandler(this.textBoxCode_TextChanged);
            // 
            // textBoxSig
            // 
            this.textBoxSig.Location = new System.Drawing.Point(54, 71);
            this.textBoxSig.Name = "textBoxSig";
            this.textBoxSig.Size = new System.Drawing.Size(226, 20);
            this.textBoxSig.TabIndex = 2;
            this.textBoxSig.TextChanged += new System.EventHandler(this.textBoxSig_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sig";
            // 
            // buttonGenCode
            // 
            this.buttonGenCode.Location = new System.Drawing.Point(50, 97);
            this.buttonGenCode.Name = "buttonGenCode";
            this.buttonGenCode.Size = new System.Drawing.Size(75, 23);
            this.buttonGenCode.TabIndex = 5;
            this.buttonGenCode.Text = "Generate";
            this.buttonGenCode.UseVisualStyleBackColor = true;
            this.buttonGenCode.Click += new System.EventHandler(this.buttonGenCode_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(215, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 9);
            this.label3.TabIndex = 6;
            this.label3.Text = "by cannon / kazinsal";
            // 
            // buttonSave
            // 
            this.buttonSave.Enabled = false;
            this.buttonSave.Location = new System.Drawing.Point(127, 97);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 7;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonHelp
            // 
            this.buttonHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonHelp.Image = global::FLKeyGen.Properties.Resources.help;
            this.buttonHelp.Location = new System.Drawing.Point(12, 108);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Size = new System.Drawing.Size(24, 24);
            this.buttonHelp.TabIndex = 8;
            this.buttonHelp.UseVisualStyleBackColor = true;
            this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setFAMDirectoryToolStripMenuItem,
            this.detectFAMDirectoryToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // setFAMDirectoryToolStripMenuItem
            // 
            this.setFAMDirectoryToolStripMenuItem.Name = "setFAMDirectoryToolStripMenuItem";
            this.setFAMDirectoryToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.setFAMDirectoryToolStripMenuItem.Text = "Set FAM Directory...";
            this.setFAMDirectoryToolStripMenuItem.Click += new System.EventHandler(this.setFAMDirectoryToolStripMenuItem_Click);
            // 
            // detectFAMDirectoryToolStripMenuItem
            // 
            this.detectFAMDirectoryToolStripMenuItem.Name = "detectFAMDirectoryToolStripMenuItem";
            this.detectFAMDirectoryToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.detectFAMDirectoryToolStripMenuItem.Text = "Detect FAM Directory";
            this.detectFAMDirectoryToolStripMenuItem.Click += new System.EventHandler(this.detectFAMDirectoryToolStripMenuItem_Click);
            // 
            // buttonSaveFAM
            // 
            this.buttonSaveFAM.Enabled = false;
            this.buttonSaveFAM.Location = new System.Drawing.Point(205, 97);
            this.buttonSaveFAM.Name = "buttonSaveFAM";
            this.buttonSaveFAM.Size = new System.Drawing.Size(75, 23);
            this.buttonSaveFAM.TabIndex = 10;
            this.buttonSaveFAM.Text = "Save / FAM";
            this.buttonSaveFAM.UseVisualStyleBackColor = true;
            this.buttonSaveFAM.Click += new System.EventHandler(this.buttonSaveFAM_Click);
            // 
            // FLKeyGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 144);
            this.Controls.Add(this.buttonSaveFAM);
            this.Controls.Add(this.buttonHelp);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonGenCode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxSig);
            this.Controls.Add(this.textBoxCode);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FLKeyGen";
            this.Text = "FLKeyGen";
            this.Load += new System.EventHandler(this.FLKeyGen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxCode;
        private System.Windows.Forms.TextBox textBoxSig;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonGenCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setFAMDirectoryToolStripMenuItem;
        private System.Windows.Forms.Button buttonSaveFAM;
        private System.Windows.Forms.ToolStripMenuItem detectFAMDirectoryToolStripMenuItem;
    }
}

