﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace FLKeyGen
{
    /// <summary>
    /// A Freelancer Account ID Generator.
    /// by Cannon 7-July-2009
    /// </summary>
    public partial class FLKeyGen : Form
    {
        public FLKeyGen()
        {
            InitializeComponent();
        }

        // Return an MD5 digest for the specified string.
        public string GetMD5Hash(string input)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(input);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            string password = s.ToString();
            return password;
        }

        /// <summary>
        /// Generate a new account ID code.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonGenCode_Click(object sender, EventArgs e)
        {
            // Generate a random-ish seed. This uniquely identifies the user.
            // Freelancer uses the MS windows product ID then the user ID 
            // and the current user name and time.
            string randomKey = System.Guid.NewGuid().ToString() + DateTime.Now.ToLongTimeString();
            string hash = GetMD5Hash(randomKey);

            // Add the dashes to make the code up to 35 characters.
            textBoxCode.Text = "";
            for (int b = 0; b < 32; b += 8)
            {
                string block = hash.Substring(b, 8);
                if (b != 0)
                    textBoxCode.Text += "-";
                textBoxCode.Text += block;
            }

            // Hash the code and check the length of code and sig
            hash = GetMD5Hash(textBoxCode.Text);
            if (textBoxCode.Text.Length != 35 && hash.Length != 32)
            {
                textBoxSig.Text = "Invalid code";
                return;
            }
       
            // Break the hash into 4 blocks and reverse the order 
            // of the digit pairs in each block.
            textBoxSig.Text = "";
            for (int b = 0; b < 32; b += 8)
            {
                string blockOut = "";
                string block = hash.Substring(b, 8);
                for (int i = 6; i >= 0; i -= 2)
                {
                    blockOut += block.Substring(i, 2);
                }
                if (b != 0)
                    textBoxSig.Text += "-";
                textBoxSig.Text += blockOut;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "ADF (*.adf)|*.adf";
            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter fs = File.CreateText(dialog.FileName))
                    {
                        fs.WriteLine("DB Version: 101");
                        fs.WriteLine("New Freelancer Account");
                        fs.WriteLine(textBoxCode.Text);
                        fs.WriteLine(textBoxSig.Text);
                        fs.WriteLine("<COMENTARIO>");
                        fs.WriteLine("Created using Cannon and Kazinsal's Freelancer account generator");
                        fs.WriteLine("</COMENTARIO>");
                        fs.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error '"+ex.Message+"'", "Error");
                }
            }
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Freelancer Account ID Generator v2.1\nBy Cannon and Kazinsal\n\nClick \"Generate\" to generate a new account ID and \"Save\" to save it to an ADF file.\nPress \"Save / FAM\" to save an ID directly to FAM.\n\nTo be able to save to FAM, either FLKeyGen must have detected a FAM installation, or one must be specified manually.\n\nYou can run the program from the command line with a filename as the argument to silently create an ADF file with a new ID in it.", "About/Help");
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void setFAMDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FAMFolder = new FolderBrowserDialog();
            if (FAMFolder.ShowDialog(this) == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter fs = File.CreateText(Application.StartupPath + "\\FAM.cfg"))
                    {
                        fs.WriteLine(FAMFolder.SelectedPath);
                        fs.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error '"+ex.Message+"'", "Error");
                }
            }
        }

        private void buttonSaveFAM_Click(object sender, EventArgs e)
        {
            if (File.Exists(Application.StartupPath + "\\FAM.cfg"))
            {
                try
                {
                    using (StreamReader fs = File.OpenText(Application.StartupPath + "\\FAM.cfg"))
                    {
                        string FAMFolder = fs.ReadLine();
                        fs.Close();

                        try
                        {
                            using (StreamWriter fs2 = File.AppendText(FAMFolder + "\\Accounts.dat"))
                            {
                                fs2.WriteLine("New Freelancer Account");
                                fs2.WriteLine(textBoxCode.Text);
                                fs2.WriteLine(textBoxSig.Text);
                                fs2.WriteLine("<COMENTARIO>");
                                fs2.WriteLine("Created using Cannon and Kazinsal's Freelancer account generator");
                                fs2.WriteLine("</COMENTARIO>");
                                fs2.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error '" + ex.Message + "'", "Error");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error '" + ex.Message + "'", "Error");
                }
            }

            else
            {
                MessageBox.Show("Cannot save to FAM: No FAM directory has been detected or set.", "FAM Save Error");
            }
        }

        private void FLKeyGen_Load(object sender, EventArgs e)
        {
            if (File.Exists(Application.StartupPath + "\\FAM.cfg") == false)
            {
                if (Directory.Exists("C:\\Program Files\\Freelancer Account Manager"))
                {
                    try
                    {
                        using (StreamWriter fs = File.CreateText(Application.StartupPath + "\\FAM.cfg"))
                        {
                            fs.WriteLine("C:\\Program Files\\Freelancer Account Manager");
                            fs.Close();

                            MessageBox.Show("Freelancer Account Manager found at 'C:\\Program Files\\Freelancer Account Manager', using as FAM directory.", "FAM Found!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error '" + ex.Message + "'", "Error");
                    }
                }
                else if (Directory.Exists("C:\\Program Files (x86)\\Freelancer Account Manager"))
                {
                    try
                    {
                        using (StreamWriter fs = File.CreateText(Application.StartupPath + "\\FAM.cfg"))
                        {
                            fs.WriteLine("C:\\Program Files (x86)\\Freelancer Account Manager");
                            fs.Close();

                            MessageBox.Show("Freelancer Account Manager found at 'C:\\Program Files (x86)\\Freelancer Account Manager', using as FAM directory.", "FAM Found!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error '" + ex.Message + "'", "Error");
                    }
                }
            }
        }

        private void detectFAMDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Directory.Exists("C:\\Program Files\\Freelancer Account Manager"))
            {
                try
                {
                    using (StreamWriter fs = File.CreateText(Application.StartupPath + "\\FAM.cfg"))
                    {
                        fs.WriteLine("C:\\Program Files\\Freelancer Account Manager");
                        fs.Close();

                        MessageBox.Show("Freelancer Account Manager found at 'C:\\Program Files\\Freelancer Account Manager', using as FAM directory.", "FAM Found!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error '" + ex.Message + "'", "Error");
                }
            }
            else if (Directory.Exists("C:\\Program Files (x86)\\Freelancer Account Manager"))
            {
                try
                {
                    using (StreamWriter fs = File.CreateText(Application.StartupPath + "\\FAM.cfg"))
                    {
                        fs.WriteLine("C:\\Program Files (x86)\\Freelancer Account Manager");
                        fs.Close();

                        MessageBox.Show("Freelancer Account Manager found at 'C:\\Program Files (x86)\\Freelancer Account Manager', using as FAM directory.", "FAM Found!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error '" + ex.Message + "'", "Error");
                }
            }
            else
            {
                MessageBox.Show("No FAM directory found. Please specify one manually in 'Options->Set FAM Directory...'!", "FAM Not Found");
            }
        }

        private void textBoxCode_TextChanged(object sender, EventArgs e)
        {
            if (textBoxCode.Text == "")
            {
                buttonSave.Enabled = false;
                buttonSaveFAM.Enabled = false;
            }
            else
            {
                buttonSave.Enabled = true;
                buttonSaveFAM.Enabled = true;
            }
        }

        private void textBoxSig_TextChanged(object sender, EventArgs e)
        {
            if (textBoxSig.Text == "")
            {
                buttonSave.Enabled = false;
                buttonSaveFAM.Enabled = false;
            }
            else
            {
                buttonSave.Enabled = true;
                buttonSaveFAM.Enabled = true;
            }
        }
    }
}
