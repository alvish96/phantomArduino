# Bluetooth-LED-Remote-Control-Evothings-App
LED On/Off Example using HC-05 Bluetooth Module, Arduino, Cordova and Evothings
This project is to work with <a href="evothings.com">Evothings</a> Workbench and Evothings Android Client
This is to go with my tutorial about remotely controlling a LED using one's mobile phone, you can read the complete tutorial at: http://www.instructables.com/id/Remotely-Control-LED-using-HC-05-Bluetooth-Arduino/
